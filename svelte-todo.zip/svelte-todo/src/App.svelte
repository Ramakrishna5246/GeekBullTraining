<script>
import Header from "./components/Header.svelte";
import List from "./components/List.svelte";
</script>
<style>
	.container {
		width: 1500px;
		background: #009579;
	}
	:global(.container *) {
		font-family: "sample text", sans-serif;
	}
</style>
<div class="container">
	<Header></Header>
	<List></List>
</div>