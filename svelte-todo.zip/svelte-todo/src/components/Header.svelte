<script>
import { items } from "./../stores";
$: itemCount = $items.length;
$: itemCompleted = $items.filter(item => item.completed).length;
</script>

<style>
    .header {
        display: flex;
        justify-content:space-between;
        align-items: center;
        padding: 20px 20px;
        color: #fff;
        font-weight: bold;
        font-size: 2em;
        background: rgba(0, 0, 0, 0.1);
    }
</style>
<div class="header">
    <span>To-Do List</span>
    <span>{itemCompleted}/{itemCount}</span>
</div>