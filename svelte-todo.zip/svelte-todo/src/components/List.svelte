<script>
    import { onMount } from "svelte";
    import { items } from "../stores";
    import ToDoApi from "../ToDoApi";
    import Item from "./Item.svelte";
    import NewItem from "./NewItem.svelte";
    function handleNewItem(e) {
        console.log(e);
    }

    function handleUpdate(e) {
        const index = $items.findIndex(item => item.id === e.detail.id);
        $items[index] = e.detail;
        ToDoApi.save($items);
    }

    function handleDelete(e) {
        $items =  $items.filter(item => item.id !== e.detail);
        ToDoApi.save($items);
    }

    onMount(async () => {
    // fetch from API
        $items = await ToDoApi.getAll();
        console.log($items);
   });
</script>

<style>
.list {
    padding: 15px;
}
.list-status {
    margin: 0;
    text-align: center;
    padding: 15px;
    color: #fff;
    font-weight: bold;
    font-size: 1.1em;
}

</style>
<div class="list">
    <NewItem on:newitem:{handleNewItem}/>
    {#each $items as item (item) }
    <Item {...item} on:update={handleUpdate} on:delete={handleDelete} />
    {:else}
    <p class="list-status">No Items Exist</p>
        
    {/each}
</div>