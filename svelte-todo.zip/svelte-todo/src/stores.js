import { writable } from "svelte/store";

export const items = writable([
    {
        id: 1,
        text: "Take out bins",
        completed: false
    },
    {
        id: 2,
        text: "Go to school",
        completed: true
    }


]); 